# Implementation notes for the presenter

## Decisions and rationale

- **LangGraph rather than a single chain:** explicit node boundaries make each agent inspectable, add bounded retries and keep orchestration state explicit.
- **LangChain + ChatNVIDIA:** model access is swappable via environment configuration and works with NVIDIA-hosted or self-hosted NIM where supported.
- **Dual retrieval mode:** the project is testable without credentials. Offline lexical retrieval supports a genuine end-to-end workflow; NVIDIA embeddings + Chroma provide semantic vector retrieval when configured.
- **Citation references:** each retrieved passage gets a request-local label; the source panel carries filename, page/slide and excerpt. The answer should cite IDs, not invent URLs.
- **Fail-safe posture:** if no evidence is retrieved, the analyst should abstain rather than answer from general knowledge. In a real environment, source permissions must be checked before retrieval.
- **Evaluation:** a baseline is included so changes are measured. Production evaluation must include ground-truth answers, semantic entailment and domain owner review.

## Demo script

1. Start Streamlit in offline mode and ask: “How long do employees have to submit expense claims?”
2. Explain that the response is based on the travel expense sample doc and is annotated with a request-local source ID.
3. Click the source expander and show excerpt, source, validation flags and trace ID.
4. Show `knowledge_agent/graph.py`: researcher → analyst → validator → bounded retry.
5. Run `python scripts/evaluate.py` and explain expected-source hit rate vs the limits of a small smoke test.
6. Open `/docs` and explain how a consuming business application would call `/ask`.
7. Switch to NVIDIA NIM only after a key/model is approved and configured; show same app with live inference.

## Questions a client/interviewer may ask

**How do you stop hallucinations?** Ground answer generation in retrieved passages, require source IDs, abstain on missing evidence, run citation validation, measure claim-level groundedness and route uncertain cases to a human. No prompt alone eliminates hallucinations.

**Why multi-agent?** The roles separate evidence finding, synthesis, and verification. LangGraph makes the workflow observable and supports bounded recovery. For tiny use cases, a single RAG chain can be cheaper; use multi-agent only where validation/research loops justify the added latency.

**How do you secure client data?** Enforce SSO/RBAC and document ACLs before search, keep secrets in a vault, use approved/private NIM deployment, encrypt traffic/storage, limit logs, audit access, and validate the data processing location and retention model. The demo is not enterprise secured by default.

**How do you evaluate it?** Retrieval Recall@k/MRR, citation precision, claim-level groundedness, answer correctness rated by domain experts, abstention quality, P95 latency, model and embedding cost, and regression tests against a golden set.

**Why NVIDIA NIM?** It gives a consistent inference interface for approved NVIDIA-hosted models or self-hosted inference containers, depending on deployment and licensing. Availability, model identifiers and controls are deployment-specific.
