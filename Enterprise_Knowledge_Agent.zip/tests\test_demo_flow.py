from __future__ import annotations

import os

# Force deterministic/offline behaviour for unit tests before importing the app modules.
os.environ["DEMO_MODE"] = "true"
os.environ["RETRIEVAL_MODE"] = "lexical"

from knowledge_agent.graph import answer_question
from knowledge_agent.ingestion import chunk_text, ingest_documents


def test_chunker_returns_bounded_chunks():
    text = "Paragraph one with enough content. " * 50
    chunks = chunk_text(text, chunk_size=300, overlap=30)
    assert chunks
    assert all(len(chunk) <= 300 for chunk in chunks)


def test_ingestion_finds_sample_documents():
    result = ingest_documents()
    assert result["chunk_count"] >= 4
    assert "travel_expense_policy.md" in result["source_files"]


def test_answer_includes_sources_for_known_question():
    result = answer_question("How long do employees have to submit expense claims?")
    assert result["answer"]
    assert result["sources"]
    assert any(s["source"] == "travel_expense_policy.md" for s in result["sources"])
    assert result["trace_id"]


def test_unknown_question_does_not_crash():
    result = answer_question("What is the policy for underwater moon gardening?")
    assert result["answer"]
    assert result["validation"] is not None
