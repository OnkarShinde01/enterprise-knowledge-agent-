"""Validated FastAPI input/output contracts."""
from __future__ import annotations

from typing import Any
from pydantic import BaseModel, Field


class AskRequest(BaseModel):
    question: str = Field(min_length=3, max_length=2000, description="Question to research in indexed enterprise documents")
    top_k: int = Field(default=5, ge=1, le=12, description="Maximum passages to retrieve")


class SourceReference(BaseModel):
    source_id: str
    source: str
    page: int | None = None
    score: float | None = None
    excerpt: str


class AskResponse(BaseModel):
    trace_id: str
    question: str
    answer: str
    sources: list[SourceReference]
    validation: dict[str, Any]
    retrieval_mode: str
    llm_mode: str
    retry_count: int
    latency_ms: int
