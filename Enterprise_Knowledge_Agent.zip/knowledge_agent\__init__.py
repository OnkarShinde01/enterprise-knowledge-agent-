"""Enterprise Knowledge Research Agent starter application."""
__version__ = "1.0.0"
