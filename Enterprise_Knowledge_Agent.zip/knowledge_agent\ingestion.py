"""Parse common enterprise file types and create overlapping text chunks."""
from __future__ import annotations

import csv
import hashlib
import io
import json
import re
from pathlib import Path
from typing import Any

from docx import Document as DocxDocument
from pptx import Presentation
from pypdf import PdfReader

from .config import settings
from .observability import log_event

SUPPORTED_EXTENSIONS = {".pdf", ".docx", ".pptx", ".txt", ".md", ".csv"}
MAX_FILE_BYTES = 25 * 1024 * 1024


def _stable_id(path: Path) -> str:
    return hashlib.sha256(path.name.encode("utf-8")).hexdigest()[:10]


def _clean(text: str) -> str:
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def extract_file(path: Path) -> list[dict[str, Any]]:
    """Return extracted records. PDF pages and PPTX slides retain page-level metadata."""
    if path.suffix.lower() not in SUPPORTED_EXTENSIONS:
        return []
    if path.stat().st_size > MAX_FILE_BYTES:
        raise ValueError(f"{path.name} exceeds the 25 MB demo limit")
    ext = path.suffix.lower()
    records: list[dict[str, Any]] = []
    if ext == ".pdf":
        reader = PdfReader(str(path))
        for page_number, page in enumerate(reader.pages, start=1):
            text = _clean(page.extract_text() or "")
            if text:
                records.append({"text": text, "source": path.name, "file_type": ext, "page": page_number, "document_id": _stable_id(path)})
    elif ext == ".docx":
        doc = DocxDocument(str(path))
        text = _clean("\n".join(p.text for p in doc.paragraphs if p.text.strip()))
        if text:
            records.append({"text": text, "source": path.name, "file_type": ext, "page": None, "document_id": _stable_id(path)})
    elif ext == ".pptx":
        presentation = Presentation(str(path))
        for slide_number, slide in enumerate(presentation.slides, start=1):
            parts: list[str] = []
            for shape in slide.shapes:
                if getattr(shape, "has_text_frame", False) and shape.text.strip():
                    parts.append(shape.text.strip())
                if getattr(shape, "has_table", False):
                    for row in shape.table.rows:
                        parts.append(" | ".join(cell.text.strip() for cell in row.cells))
            text = _clean("\n".join(parts))
            if text:
                records.append({"text": text, "source": path.name, "file_type": ext, "page": slide_number, "document_id": _stable_id(path)})
    elif ext in {".txt", ".md"}:
        text = _clean(path.read_text(encoding="utf-8", errors="replace"))
        if text:
            records.append({"text": text, "source": path.name, "file_type": ext, "page": None, "document_id": _stable_id(path)})
    elif ext == ".csv":
        with path.open("r", encoding="utf-8-sig", errors="replace", newline="") as f:
            rows = list(csv.reader(f))
        text = _clean("\n".join(" | ".join(cell.strip() for cell in row) for row in rows))
        if text:
            records.append({"text": text, "source": path.name, "file_type": ext, "page": None, "document_id": _stable_id(path)})
    return records


def chunk_text(text: str, chunk_size: int | None = None, overlap: int | None = None) -> list[str]:
    """Chunk text with overlap while preferring paragraph/sentence boundaries."""
    size = chunk_size or settings.chunk_size
    stride_overlap = settings.chunk_overlap if overlap is None else overlap
    if stride_overlap >= size:
        raise ValueError("CHUNK_OVERLAP must be smaller than CHUNK_SIZE")
    text = _clean(text)
    if not text:
        return []
    # Split into paragraph-sized units; then pack units into bounded chunks.
    units = [u.strip() for u in re.split(r"\n\s*\n|(?<=[.!?])\s+(?=[A-Z0-9])", text) if u.strip()]
    chunks: list[str] = []
    current = ""
    for unit in units:
        # Long paragraphs are sliced in fixed windows, preserving a configurable overlap.
        if len(unit) > size:
            if current:
                chunks.append(current.strip())
                current = ""
            start = 0
            while start < len(unit):
                part = unit[start:start + size].strip()
                if part:
                    chunks.append(part)
                if start + size >= len(unit):
                    break
                start += size - stride_overlap
            continue
        candidate = f"{current}\n{unit}".strip() if current else unit
        if len(candidate) <= size:
            current = candidate
        else:
            if current:
                chunks.append(current.strip())
            tail = current[-stride_overlap:] if current and stride_overlap else ""
            # Preserve overlap only when the next unit still fits the configured bound.
            joined = f"{tail}\n{unit}".strip() if tail else unit
            current = joined if len(joined) <= size else unit
    if current:
        chunks.append(current.strip())
    return chunks


def load_and_chunk_documents(data_dir: Path | None = None) -> list[dict[str, Any]]:
    directory = data_dir or settings.data_dir
    directory.mkdir(parents=True, exist_ok=True)
    output: list[dict[str, Any]] = []
    errors: list[dict[str, str]] = []
    for path in sorted(directory.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in SUPPORTED_EXTENSIONS:
            continue
        try:
            for record in extract_file(path):
                for chunk_number, chunk in enumerate(chunk_text(record["text"]), start=1):
                    chunk_id = hashlib.sha256(f"{record['document_id']}:{record['page']}:{chunk_number}:{chunk}".encode("utf-8")).hexdigest()[:16]
                    output.append({
                        "chunk_id": chunk_id,
                        "text": chunk,
                        "source": record["source"],
                        "file_type": record["file_type"],
                        "page": record["page"],
                        "document_id": record["document_id"],
                        "chunk_number": chunk_number,
                    })
        except Exception as exc:  # capture corrupt/unsupported files without killing all ingestion
            errors.append({"file": path.name, "error": str(exc)[:300]})
            log_event("document_parse_failed", file_name=path.name, error_type=type(exc).__name__, error=str(exc)[:250])
    return output


def ingest_documents() -> dict[str, Any]:
    """Rebuild the chunk manifest and optional NVIDIA/Chroma index."""
    import shutil

    settings.storage_dir.mkdir(parents=True, exist_ok=True)

    # Step 1: Extract and chunk every supported document.
    chunks = load_and_chunk_documents()

    # Step 2: Persist the searchable chunk manifest.
    with settings.chunks_file.open("w", encoding="utf-8") as file:
        for chunk in chunks:
            file.write(json.dumps(chunk, ensure_ascii=False) + "\n")

    vector_status = "not_requested"

    # Step 3: Build the vector index when live vector retrieval is enabled.
    if settings.live_vector_enabled and chunks:
        try:
            from langchain_chroma import Chroma
            from langchain_core.documents import Document

            from .nvidia_embeddings import NVIDIAEmbeddingAdapter

            # Rebuild the existing local index.
            if settings.chroma_dir.exists():
                shutil.rmtree(settings.chroma_dir)

            settings.chroma_dir.mkdir(parents=True, exist_ok=True)

            # Document indexing explicitly uses input_type="passage".
            # The adapter implements this in embed_documents().
            embeddings = NVIDIAEmbeddingAdapter(
                model=settings.nvidia_embedding_model,
                api_key=settings.nvidia_api_key,
                base_url=settings.nvidia_base_url,
            )

            # Preserve metadata needed for citations and traceability.
            docs = [
                Document(
                    page_content=chunk["text"],
                    metadata={
                        key: chunk[key]
                        for key in (
                            "chunk_id",
                            "source",
                            "file_type",
                            "page",
                            "document_id",
                            "chunk_number",
                        )
                    },
                )
                for chunk in chunks
            ]

            # Create and persist the Chroma vector index.
            Chroma.from_documents(
                documents=docs,
                embedding=embeddings,
                collection_name="enterprise_knowledge",
                persist_directory=str(settings.chroma_dir),
            )

            vector_status = "ready"

        except Exception as exc:
            vector_status = (
                f"failed: {type(exc).__name__}: {str(exc)[:200]}"
            )

    elif settings.live_vector_enabled and not chunks:
        vector_status = "not_built: no documents were successfully parsed"

    elif settings.retrieval_mode == "nvidia":
        vector_status = "not_built: configure NVIDIA credentials/base URL"

    # Step 4: Return and log the ingestion result.
    result = {
        "documents_dir": str(settings.data_dir),
        "chunk_count": len(chunks),
        "source_files": sorted({chunk["source"] for chunk in chunks}),
        "vector_index": vector_status,
    }

    log_event("document_ingestion_completed", **result)

    return result