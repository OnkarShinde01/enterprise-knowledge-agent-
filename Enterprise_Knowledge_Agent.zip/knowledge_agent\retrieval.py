"""Lexical retrieval for an offline demo and NVIDIA embedding + Chroma retrieval for live mode."""
from __future__ import annotations

import json
import math
import re
from collections import Counter
from pathlib import Path
from typing import Any

from .config import settings
from .ingestion import ingest_documents
from .observability import log_event

_STOP_WORDS = {
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being", "to", "of", "and", "or", "in", "on", "for", "with", "by", "as", "at", "from", "what", "when", "where", "who", "how", "do", "does", "did", "can", "could", "should", "would", "i", "we", "you", "our", "their", "it", "this", "that", "please", "tell", "me", "about", "explain", "find", "show", "employee", "employees", "company", "companies", "policy", "policies"
}


def _tokens(text: str) -> list[str]:
    return [t for t in re.findall(r"[a-zA-Z0-9][a-zA-Z0-9_-]{1,}", text.lower()) if t not in _STOP_WORDS]


def _read_chunks() -> list[dict[str, Any]]:
    if not settings.chunks_file.exists():
        ingest_documents()
    if not settings.chunks_file.exists():
        return []
    chunks: list[dict[str, Any]] = []
    with settings.chunks_file.open("r", encoding="utf-8") as f:
        for line in f:
            try:
                chunks.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    if not chunks:
        ingest_documents()
        if settings.chunks_file.exists():
            with settings.chunks_file.open("r", encoding="utf-8") as f:
                for line in f:
                    try:
                        chunks.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass
    return chunks


def _lexical_search(query: str, top_k: int) -> list[dict[str, Any]]:
    chunks = _read_chunks()
    if not chunks:
        return []
    query_terms = set(_tokens(query))
    if not query_terms:
        query_terms = set(_tokens(query.lower()))
    corpus_tokens = [_tokens(c["text"]) for c in chunks]
    df = Counter(term for tokens in corpus_tokens for term in set(tokens))
    n_docs = len(chunks)
    ranked: list[tuple[float, dict[str, Any]]] = []
    for chunk, tokens in zip(chunks, corpus_tokens):
        counts = Counter(tokens)
        score = 0.0
        for term in query_terms:
            if counts[term]:
                idf = math.log(1 + (n_docs - df[term] + 0.5) / (df[term] + 0.5))
                score += idf * (counts[term] * 2.2) / (counts[term] + 1.2 * (0.25 + 0.75 * len(tokens) / 180))
        if score > 0:
            ranked.append((score, chunk))
    ranked.sort(key=lambda pair: pair[0], reverse=True)
    return [{**item, "score": round(score, 4)} for score, item in ranked[:top_k]]


def _nvidia_search(query: str, top_k: int) -> list[dict[str, Any]]:
    """Retrieve relevant passages from the persisted Chroma index."""
    from langchain_chroma import Chroma

    from .nvidia_embeddings import NVIDIAEmbeddingAdapter

    # Build the index if it does not exist.
    if (
        not settings.chroma_dir.exists()
        or not any(settings.chroma_dir.iterdir())
    ):
        ingest_documents()

    # The adapter uses input_type="query" for searches.
    # It uses input_type="passage" when indexing documents.
    embeddings = NVIDIAEmbeddingAdapter(
        model=settings.nvidia_embedding_model,
        api_key=settings.nvidia_api_key,
        base_url=settings.nvidia_base_url,
    )

    store = Chroma(
        collection_name="enterprise_knowledge",
        embedding_function=embeddings,
        persist_directory=str(settings.chroma_dir),
    )

    # Lower Chroma distance means a closer match.
    docs_and_distances = store.similarity_search_with_score(
        query,
        k=top_k,
    )

    results: list[dict[str, Any]] = []

    for doc, raw_distance in docs_and_distances:
        distance = float(raw_distance)

        # A bounded display proxy, not a calibrated probability.
        score = 1.0 / (1.0 + max(distance, 0.0))

        results.append({
            "text": doc.page_content,
            **doc.metadata,
            "score": round(score, 4),
            "distance": round(distance, 4),
        })

    return results
    """Retrieve documents from the persisted Chroma vector index."""
    from langchain_chroma import Chroma
    from langchain_nvidia_ai_endpoints import NVIDIAEmbeddings

    # Build the index if it does not exist yet.
    if (
        not settings.chroma_dir.exists()
        or not any(settings.chroma_dir.iterdir())
    ):
        ingest_documents()

    args: dict[str, Any] = {
        "model": settings.nvidia_embedding_model,
    }

    if settings.nvidia_api_key:
        args["nvidia_api_key"] = settings.nvidia_api_key.strip()

    if settings.nvidia_base_url:
        args["base_url"] = settings.nvidia_base_url

    embeddings = NVIDIAEmbeddings(**args)

    store = Chroma(
        collection_name="enterprise_knowledge",
        embedding_function=embeddings,
        persist_directory=str(settings.chroma_dir),
    )

    # Chroma returns distances; smaller distances indicate closer matches.
    docs_and_distances = store.similarity_search_with_score(
        query,
        k=top_k,
    )

    results: list[dict[str, Any]] = []

    for doc, raw_distance in docs_and_distances:
        distance = float(raw_distance)

        # Bounded display proxy, NOT a calibrated relevance probability.
        score = 1.0 / (1.0 + max(distance, 0.0))

        results.append({
            "text": doc.page_content,
            **doc.metadata,
            "score": round(score, 4),
            "distance": round(distance, 4),
        })

    return results


def retrieve(query: str, top_k: int | None = None, trace_id: str | None = None) -> list[dict[str, Any]]:
    k = top_k or settings.top_k
    mode = "nvidia_chroma" if settings.live_vector_enabled else "lexical_demo"
    try:
        hits = _nvidia_search(query, k) if settings.live_vector_enabled else _lexical_search(query, k)
    except Exception as exc:
        log_event("retrieval_error", trace_id=trace_id, mode=mode, error_type=type(exc).__name__, error=str(exc)[:300])
        # Fail open only into lexical retrieval, never into an ungrounded generated answer.
        hits = _lexical_search(query, k)
        mode = "lexical_fallback"
    for i, hit in enumerate(hits, start=1):
        hit["source_id"] = f"S{i}"
    log_event("retrieval_completed", trace_id=trace_id, mode=mode, top_k=k, hit_count=len(hits), sources=[h.get("source") for h in hits])
    return hits
