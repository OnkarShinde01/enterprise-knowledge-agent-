# Data Handling and Information Security — Sample Demo Policy

## Data classification
Information should be handled according to its assigned classification. Public information may be shared externally when permitted. Internal information is intended for approved business use. Confidential information must be shared only with authorized individuals who have a legitimate business need. Restricted information requires the stricter controls specified by the information owner and security team.

## Confidential information
Employees must not place confidential or restricted information into personal email, unapproved file-sharing services, public AI assistants, or unmanaged devices. Use only approved enterprise systems and access methods. Before sharing a document externally, confirm the recipient is authorized and that the information owner has approved the disclosure when required.

## Access management
Access should follow least-privilege principles: users receive only the access required to perform their role. Access requests should identify the business need and be approved by the data or application owner. Access must be removed when no longer needed or when a role change requires it.

## Suspected incident
Suspected loss, unintended disclosure, or unauthorized access should be reported promptly using the organization's official security incident process. Employees should preserve relevant facts and avoid attempting unauthorized investigation or deleting potential evidence.

## Use of AI tools
Only AI tools approved by the organization may be used with internal, confidential, or restricted information. Users must not assume that an AI-generated response is correct. Material business decisions require verification against authoritative sources and the appropriate human owner.

This is fictional sample content created solely for demonstration. It is not an official Capgemini security policy.
