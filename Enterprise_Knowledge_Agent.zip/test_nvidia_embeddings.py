import os

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

api_key = os.getenv("NVIDIA_API_KEY", "").strip()
model = os.getenv(
    "NVIDIA_EMBEDDING_MODEL",
    "nvidia/nemotron-3-embed-1b",
).strip()
base_url = (
    os.getenv("NVIDIA_BASE_URL")
    or "https://integrate.api.nvidia.com/v1"
).strip()

if not api_key:
    raise SystemExit("NVIDIA_API_KEY is missing from .env")

client = OpenAI(
    api_key=api_key,
    base_url=base_url,
    timeout=45.0,
    max_retries=0,
)

tests = [
    (
        "passage",
        "Manager approval is required before business travel bookings.",
    ),
    (
        "query",
        "What requires manager approval before booking?",
    ),
]

for input_type, text in tests:
    response = client.embeddings.create(
        model=model,
        input=[text],
        extra_body={"input_type": input_type},
    )

    embedding = response.data[0].embedding

    print(
        f"{input_type}: success | "
        f"dimensions={len(embedding)} | "
        f"model={response.model}"
    )