# Enterprise Knowledge Research Agent

A runnable starter implementation for a multi-agent enterprise document research assistant. It demonstrates document ingestion, retrieval, evidence-grounded synthesis, citation validation, a bounded research retry loop, structured logs, an evaluation script, a FastAPI endpoint, and a Streamlit interface.

> **Important:** the included documents are fictional demo policies. They are not official Capgemini/client policies. Do not upload confidential data into this starter or a personal/unapproved NVIDIA account. Follow your organization's data classification, security, AI-use and client approval requirements.

## 1. What is implemented

- **Ingestion:** PDF, DOCX, PPTX, TXT, Markdown and CSV parsing. PDF pages and PPTX slides retain page/slide metadata. Text is chunked with overlap into a JSONL manifest.
- **Retrieval:** offline lexical ranking by default so the project runs before API credentials are available. Optional NVIDIA embedding inference + Chroma vector search when configured.
- **Researcher agent:** searches indexed content and assigns request-local source labels such as `[S1]`.
- **Analyst agent:** in live mode uses a LangChain `ChatNVIDIA` model to answer only from retrieved evidence. In offline mode extracts relevant sentences with citations.
- **Validator agent:** checks citation IDs against retrieved source IDs, checks citation coverage, and can trigger one bounded search retry.
- **Orchestration:** LangGraph `StateGraph` with explicit nodes and conditional edges.
- **API/UI:** FastAPI `/health`, `/ask`, and protected `/documents/ingest`; Streamlit chat UI with source excerpts.
- **Observability:** JSON Lines events in `logs/app.jsonl`; no API keys or whole document text are logged.
- **Evaluation:** a small deterministic evaluation suite checking expected source retrieval, citation format and latency.
- **Tests:** basic chunking, ingestion, known-question retrieval and unknown-question smoke tests.

## 2. Architecture

```text
                     ┌─────────────────────────────┐
                     │ Streamlit UI / FastAPI API  │
                     └──────────────┬──────────────┘
                                    │ question
                     ┌──────────────▼──────────────┐
                     │       LangGraph StateGraph  │
                     │                              │
                     │ Researcher → Analyst →       │
                     │ Validator ──┬── finish       │
                     │             └── retry →      │
                     │                Researcher    │
                     └──────────────┬───────────────┘
                                    │
            ┌───────────────────────▼────────────────────────┐
            │ Retrieval                                      │
            │ Demo: lexical ranking                          │
            │ Live: NVIDIA embeddings + Chroma vector search │
            └───────────────────────▲────────────────────────┘
                                    │ indexed chunks
            ┌───────────────────────┴────────────────────────┐
            │ Ingestion: extract → chunk → metadata → index  │
            └───────────────────────▲────────────────────────┘
                                    │
             PDF / DOCX / PPTX / TXT / MD / CSV documents

      Cross-cutting: structured logs · citation checks · evaluation suite
```

## 3. Prerequisites

- Windows 10/11, macOS, or Linux.
- Python **3.11 or 3.12** recommended.
- VS Code with the Python extension.
- Internet access only to install Python packages and, for live mode, call the NVIDIA endpoint.
- An NVIDIA API Catalog key or an approved/self-hosted NVIDIA NIM endpoint **only if you want live LLM inference**. The offline demo requires no key.

## 4. Run from scratch in VS Code (Windows PowerShell)

Open the extracted `enterprise_knowledge_agent` folder in VS Code. Open **Terminal → New Terminal** and run:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

If PowerShell blocks activation, use the current terminal only:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

Choose the `.venv` interpreter in VS Code (`Ctrl+Shift+P` → **Python: Select Interpreter**).

### Step A — index the supplied sample documents

```powershell
python scripts/ingest.py
```

Expected result: a JSON report showing the sample files and chunk count. A local `storage/chunks.jsonl` file is created. This is the transparent source manifest used by demo retrieval.

### Step B — start the chat UI

```powershell
streamlit run app.py
```

Open the URL printed in the terminal (usually `http://localhost:8501`). Ask one of these questions:

- What expenses require manager approval before booking?
- How should confidential information be handled?
- What is needed for a normal production change?
- How can an employee request remote work?
- How long do employees have to submit expense claims?

Expand **Sources and validation** to inspect the cited file, page/slide where available, evidence excerpt, citation coverage, retry count and trace ID.

### Step C — run the API (separate terminal)

Keep the virtual environment activated in the second terminal:

```powershell
uvicorn api:app --reload --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000/docs` for the interactive API documentation. Test `/health`, then try `/ask` with:

```json
{
  "question": "How long do employees have to submit expense claims?",
  "top_k": 5
}
```

By default, `API_AUTH_TOKEN` is blank for a localhost-only demo. Before exposing the API beyond localhost, configure authentication and deploy behind your approved identity gateway. The ingestion endpoint is disabled until `ADMIN_API_TOKEN` is configured.

### Step D — run tests and evaluation

```powershell
python -m pytest -q
python scripts/evaluate.py
```

Evaluation output is printed and saved to `reports/evaluation_latest.json`. The starter checks retrieval and citation-format signals; it is **not** a rigorous semantic-accuracy benchmark.

## 5. Enable NVIDIA NIM live mode

1. Obtain an NVIDIA API Catalog key for a model your account can call, or get the endpoint URL for your approved self-hosted NIM.
2. Open `.env` and set the values below. Never commit `.env`, paste keys into source files, or share keys in screenshots.

```dotenv
DEMO_MODE=false
RETRIEVAL_MODE=nvidia
NVIDIA_API_KEY=nvapi-REPLACE_WITH_YOUR_PRIVATE_KEY
NVIDIA_CHAT_MODEL=meta/llama-3.3-70b-instruct
NVIDIA_EMBEDDING_MODEL=nvidia/nv-embedqa-e5-v5
NVIDIA_BASE_URL=
```

The default model names are examples; use model identifiers available in your approved NVIDIA environment. For a self-hosted NIM, supply `NVIDIA_BASE_URL` such as `http://localhost:8000/v1` if that is your endpoint and authentication configuration. Do not assume API Catalog access and a local NIM use the same model name or permissions.

Then rebuild the index and restart the app:

```powershell
python scripts/ingest.py
streamlit run app.py
```

When NVIDIA embeddings are enabled, ingestion calls the embedding endpoint and persists vectors in `storage/chroma`. The chat model is invoked at question time. The first call may take longer. Check terminal logs and `/health` if the API returns an error.

If you only have a chat key but do not want to configure embeddings yet, set `DEMO_MODE=false` and `RETRIEVAL_MODE=lexical`. This keeps lexical retrieval but uses NVIDIA NIM for answer synthesis.

## 6. How the LangGraph workflow works

1. **Researcher** retrieves the top passages for the user question and labels them `[S1]`, `[S2]`, and so on.
2. **Analyst** either extracts matching sentences in offline demo mode or asks NVIDIA NIM to synthesize an answer from the provided context. Prompt rules disallow unsupported facts and citations that were not retrieved.
3. **Validator** checks whether source labels exist, whether invalid citations were used, and whether answer sentences have citation coverage.
4. **Conditional retry**: if the answer fails these basic checks, the graph broadens the search query and retries up to `MAX_RESEARCH_RETRIES`.
5. The API/UI returns the answer, source passages, validation flags, latency and trace ID.

This is a practical starter validation, not a formal guarantee that the cited passage entails each claim. For production, add independent semantic groundedness checks, a domain-owner review workflow, adversarial tests, and acceptance thresholds.

## 7. Project structure

```text
enterprise_knowledge_agent/
├── app.py                         # Streamlit demo
├── api.py                         # FastAPI service
├── requirements.txt
├── .env.example                   # Copy to .env
├── knowledge_agent/
│   ├── config.py                  # Config/secrets
│   ├── ingestion.py               # File parsing/chunking/index build
│   ├── retrieval.py               # Lexical + NVIDIA/Chroma retrieval
│   ├── graph.py                   # Research/analysis/validation LangGraph
│   ├── schemas.py                 # API contracts
│   └── observability.py           # JSONL structured logs
├── data/
│   ├── documents/                 # Synthetic demo policies / put approved files here
│   └── evaluation_questions.json
├── scripts/ingest.py              # Rebuild index
├── scripts/evaluate.py            # Run small evaluation suite
├── tests/test_demo_flow.py
├── storage/                       # Generated chunk manifest/vector index
├── logs/                          # Runtime logs
└── reports/                       # Evaluation reports
```

## 8. Client-ready demo storyline (5–7 minutes)

1. **Business problem (30 seconds):** enterprise policies are spread across many files; manual searches consume time and make answers hard to audit.
2. **Ingest (45 seconds):** show policy documents in `data/documents`, run `python scripts/ingest.py`, and explain metadata/chunking.
3. **Ask a common question (60 seconds):** ask about expense approvals or data confidentiality; show answer plus cited passages.
4. **Show traceability (45 seconds):** expand source details and validation fields; explain that citations are source IDs tied to retrieved passages.
5. **Show orchestration (60 seconds):** open `knowledge_agent/graph.py` and explain researcher → analyst → validator plus retry branch.
6. **Show operations (45 seconds):** open `/docs`, call `/health`, run the evaluation script, and inspect JSONL logs.
7. **Production path (60 seconds):** explain access control, document-level permissions, secrets management, real evaluation data, deployment, cost/latency monitoring, and human approval for high-impact answers.

## 9. Production hardening checklist

Before using real client documents or deploying beyond a local demo, implement and get approval for:

- SSO/OIDC authentication, role-based authorization, and **document-level ACL enforcement before retrieval**. Do not rely on prompt instructions to implement permissions.
- Approved model hosting, region/residency, retention, and vendor/data-processing review. Never send confidential client data to a public endpoint without authorization.
- Secret vault or managed identity instead of `.env`; rotate keys and restrict endpoint access.
- Malware scanning, MIME/signature checks, upload quotas, parser sandboxing, duplicate detection, source versioning and deletion propagation.
- Encryption at rest/in transit, network segmentation, private endpoint, TLS, API rate limits, request size limits and structured audit events.
- Prompt-injection defence: retrieved document contents are untrusted; do not let source text select tools, change access rules, or override system controls.
- Claim-level grounding evaluation, golden Q&A sets curated by document owners, regression tests, abstention tests, retrieval metrics (Recall@k/MRR), answer correctness review, and latency/cost SLOs.
- Human-in-the-loop review for sensitive domains, low-confidence answers, contradictory sources and actions that affect a user or system.
- Observability dashboards, alerting, versioned prompts/models/indexes, rollback strategy, disaster recovery and periodic access review.

## 10. Known starter limitations

- The offline demo mode is deliberately extractive, not a substitute for an LLM.
- Default retrieval uses lightweight lexical scoring. NVIDIA embeddings + Chroma are included for a live vector search path; consider hybrid sparse+dense search and reranking for production.
- Current validator checks source-ID validity and citation coverage, not semantic claim entailment.
- Sample corpus is tiny and fictional. Evaluation results are only a smoke test.
- `API_AUTH_TOKEN` and `ADMIN_API_TOKEN` are optional local-demo controls, not a replacement for enterprise identity and network security.
- Scanned image-only PDFs need OCR; this starter only extracts embedded PDF text.

## 11. Troubleshooting

**`ModuleNotFoundError`**: ensure the `.venv` interpreter is selected and run `pip install -r requirements.txt` in the project terminal.

**`py -3.11` not found**: install Python 3.11 or use the Python version installed on the machine, then use `python -m venv .venv`.

**PowerShell won't activate `.venv`**: run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` and retry activation, or activate using the terminal type for your shell.

**NVIDIA 401/403/model error**: check the key, model availability, account entitlement, base URL, and whether your organization permits that endpoint. Never print the key in logs.

**Vector retrieval errors**: switch `RETRIEVAL_MODE=lexical` to validate the end-to-end workflow first; then configure a supported embedding model and rerun `python scripts/ingest.py`.

**No citations or no hits**: test with the supplied sample questions, rebuild with `python scripts/ingest.py`, and inspect `storage/chunks.jsonl` to make sure documents were parsed.

## 12. Official technical references

- LangGraph state graphs and conditional routing: https://reference.langchain.com/python/langgraph/graph/state/StateGraph
- NVIDIA LangChain integration (`ChatNVIDIA`, `NVIDIAEmbeddings`): https://reference.langchain.com/python/langchain-nvidia-ai-endpoints
- NVIDIA NIM LLM API reference: https://docs.nvidia.com/nim/large-language-models/latest/reference/api-reference.html
- Chroma vector store integration: https://reference.langchain.com/python/langchain-chroma
- FastAPI: https://fastapi.tiangolo.com/
- Streamlit: https://docs.streamlit.io/get-started
