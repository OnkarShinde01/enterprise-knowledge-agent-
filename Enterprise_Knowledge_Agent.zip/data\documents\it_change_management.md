# IT Change Management — Sample Demo Procedure

## Standard change
A standard change is low risk, repeatable, documented, and pre-approved through the organization's change process. The change record should include the service affected, implementation steps, validation steps, back-out plan, owner, and planned time window.

## Normal production change
A normal production change requires a change record and review by the authorized change approver before implementation. The requester should document business justification, impact assessment, dependencies, test evidence, implementation steps, communication plan, and rollback procedure. Changes with material service or customer impact should be coordinated with relevant service owners.

## Emergency change
An emergency change is permitted only when urgent action is needed to restore service, address a critical security risk, or prevent serious business impact. The emergency process requires approval from the designated emergency change authority before implementation whenever feasible. If immediate action is unavoidable, the owner must record the rationale and obtain retrospective review as soon as possible under the organization's procedure.

## Post-implementation review
The change owner should record the outcome, validation evidence, incidents or deviations, and any follow-up actions. Failed changes must be documented, and the rollback plan should be executed when required to protect service stability.

This is fictional sample content created solely for demonstration. It is not an official Capgemini change-management policy.
