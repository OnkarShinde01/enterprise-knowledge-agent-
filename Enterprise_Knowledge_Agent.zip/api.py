"""FastAPI service layer. Keep it bound to localhost during the demo."""
from __future__ import annotations

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import JSONResponse

from knowledge_agent.config import settings, validate_settings
from knowledge_agent.graph import answer_question
from knowledge_agent.ingestion import ingest_documents
from knowledge_agent.schemas import AskRequest, AskResponse, SourceReference
from knowledge_agent.observability import log_event

app = FastAPI(
    title="Enterprise Knowledge Research Agent API",
    version="1.0.0",
    description="Evidence-backed enterprise-document research using LangGraph, LangChain and optional NVIDIA NIM inference.",
)


def _check_api_key(x_api_key: str | None = Header(default=None)) -> None:
    if settings.api_auth_token and x_api_key != settings.api_auth_token:
        raise HTTPException(status_code=401, detail="Missing or invalid API key")


def _check_admin_token(x_admin_token: str | None = Header(default=None)) -> None:
    if not settings.admin_api_token:
        raise HTTPException(status_code=503, detail="Ingestion API is disabled. Configure ADMIN_API_TOKEN to enable it.")
    if x_admin_token != settings.admin_api_token:
        raise HTTPException(status_code=401, detail="Missing or invalid admin token")


@app.get("/health")
def health() -> dict:
    return {
        "status": "ok",
        "service": "enterprise-knowledge-research-agent",
        "mode": "nvidia_nim" if settings.live_llm_enabled else "offline_demo",
        "retrieval_mode": "nvidia_chroma" if settings.live_vector_enabled else "lexical_demo",
        "warnings": validate_settings(),
    }


@app.post("/ask", response_model=AskResponse, dependencies=[Depends(_check_api_key)])
def ask(payload: AskRequest) -> AskResponse:
    try:
        result = answer_question(payload.question, top_k=payload.top_k)
        source_models = [SourceReference(
            source_id=s.get("source_id", "S?"),
            source=s.get("source", "unknown"),
            page=s.get("page"),
            score=s.get("score"),
            excerpt=s.get("text", "")[:500],
        ) for s in result["sources"]]
        return AskResponse(**{**result, "sources": source_models})
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        log_event("api_error", route="/ask", error_type=type(exc).__name__, error=str(exc)[:300])
        raise HTTPException(status_code=500, detail="The research request failed. Check application logs using the trace ID if one was returned.") from exc


@app.post("/documents/ingest", dependencies=[Depends(_check_admin_token)])
def ingest() -> JSONResponse:
    """Re-index files already placed in DATA_DIR. Admin token required."""
    result = ingest_documents()
    return JSONResponse(result)
