"""Streamlit front end for the Enterprise Knowledge Research Agent."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import streamlit as st

from knowledge_agent.config import settings, validate_settings
from knowledge_agent.graph import answer_question
from knowledge_agent.ingestion import SUPPORTED_EXTENSIONS, ingest_documents


# ---------------------------------------------------------
# Page configuration and styling
# ---------------------------------------------------------

st.set_page_config(
    page_title="Enterprise Knowledge Research Agent",
    page_icon="🔎",
    layout="wide",
)

st.markdown(
    """
    <style>
    .block-container {
        max-width: 1180px;
        padding-top: 1.4rem;
    }

    .hero {
        padding: 1.35rem 1.5rem;
        border-radius: 16px;
        background: linear-gradient(110deg, #10233f, #244c72);
        color: white;
        margin-bottom: 1rem;
    }

    .hero h1 {
        color: white;
        font-size: 2rem;
        margin-bottom: .35rem;
    }

    .hero p {
        color: #dbeafe;
        margin: 0;
    }

    .small-muted {
        color: #64748b;
        font-size: .85rem;
    }
    </style>

    <div class="hero">
        <h1>Enterprise Knowledge Research Agent</h1>
        <p>
            Ask questions about enterprise documents, retrieve relevant evidence,
            validate citations, and collect human reviewer feedback.
        </p>
    </div>
    """,
    unsafe_allow_html=True,
)


# ---------------------------------------------------------
# Human-in-the-Loop feedback utilities
# ---------------------------------------------------------

def get_feedback_file() -> Path:
    """Return the local JSONL file used to store reviewer decisions."""
    return Path(__file__).resolve().parent / "reports" / "feedback.jsonl"


def get_latest_feedback(trace_id: str) -> dict | None:
    """Find the latest saved reviewer decision for a trace ID."""
    feedback_file = get_feedback_file()

    if not feedback_file.exists():
        return None

    latest_record = None

    try:
        with feedback_file.open("r", encoding="utf-8") as file:
            for line in file:
                line = line.strip()

                if not line:
                    continue

                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue

                if record.get("trace_id") == trace_id:
                    latest_record = record

    except OSError:
        return None

    return latest_record


def record_feedback(
    trace_id: str,
    decision: str,
    comment: str = "",
) -> None:
    """Append a human reviewer decision to the local JSONL audit file."""
    if decision not in {"approved", "needs_review"}:
        raise ValueError("Unsupported review decision.")

    feedback_file = get_feedback_file()
    feedback_file.parent.mkdir(parents=True, exist_ok=True)

    record = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "trace_id": trace_id,
        "decision": decision,
        "comment": comment.strip(),
    }

    with feedback_file.open("a", encoding="utf-8") as file:
        file.write(json.dumps(record, ensure_ascii=False) + "\n")


# ---------------------------------------------------------
# Display sources, validation and reviewer controls
# ---------------------------------------------------------

def render_result_details(result: dict, item_key: str) -> None:
    """Display evidence, validation details, and human-review controls."""
    sources = result.get("sources", [])
    validation = result.get("validation", {})
    trace_id = str(result.get("trace_id") or "")

    with st.expander(
        f"Sources and validation · {len(sources)} source(s)",
        expanded=False,
    ):
        st.write(
            {
                "Validation passed": validation.get("passed"),
                "Citation coverage": validation.get("citation_coverage"),
                "Flags": validation.get("flags", []),
                "Retry count": result.get("retry_count"),
                "Trace ID": trace_id or "Unavailable",
                "Latency (ms)": result.get("latency_ms"),
            }
        )

        if not sources:
            st.info("No source evidence was returned for this answer.")

        for source in sources:
            source_id = source.get("source_id", "S?")
            source_name = source.get("source", "Unknown source")
            page = source.get("page")
            location = f" · page/slide {page}" if page else ""
            score = source.get("score", 0)

            st.markdown(
                f"**[{source_id}] {source_name}{location}** "
                f"· score `{score}`"
            )
            st.caption(source.get("text", "")[:700])

    if not trace_id:
        st.caption("Human review is unavailable because this answer has no trace ID.")
        return

    # Show the latest saved decision, if one exists.
    latest_feedback = get_latest_feedback(trace_id)

    if latest_feedback:
        decision = latest_feedback.get("decision", "unknown")
        reviewer_comment = latest_feedback.get("comment", "")
        review_time = latest_feedback.get("timestamp", "")

        if decision == "approved":
            st.success(f"Human review: Approved · {review_time}")
        else:
            st.warning(f"Human review: Needs review · {review_time}")

        if reviewer_comment:
            st.caption(f"Reviewer comment: {reviewer_comment}")

    with st.expander("Human review", expanded=False):
        st.write(
            "Check the answer against the source evidence before recording "
            "a review decision."
        )

        comment = st.text_area(
            "Reviewer comment (optional)",
            max_chars=1000,
            key=f"review_comment_{item_key}",
            placeholder="Add a reason or note for the review decision...",
        )

        approve_col, review_col = st.columns(2)

        with approve_col:
            approve_clicked = st.button(
                "Approve answer",
                key=f"approve_{item_key}",
                use_container_width=True,
                type="primary",
            )

        with review_col:
            needs_review_clicked = st.button(
                "Needs review",
                key=f"needs_review_{item_key}",
                use_container_width=True,
            )

        if approve_clicked or needs_review_clicked:
            decision = (
                "approved" if approve_clicked else "needs_review"
            )

            try:
                record_feedback(
                    trace_id=trace_id,
                    decision=decision,
                    comment=comment,
                )

                # Refresh the page so the saved decision is visible.
                st.rerun()

            except OSError as exc:
                st.error(f"Could not save the review: {exc}")

            except ValueError as exc:
                st.error(str(exc))


# ---------------------------------------------------------
# Sidebar: environment and document ingestion
# ---------------------------------------------------------

live = settings.live_llm_enabled

retrieval_label = (
    "NVIDIA embeddings + Chroma"
    if settings.live_vector_enabled
    else "Offline lexical retrieval"
)

with st.sidebar:
    st.header("Workspace")

    st.caption(
        f"LLM: {'NVIDIA NIM' if live else 'Offline demo mode'}"
    )
    st.caption(f"Retrieval: {retrieval_label}")

    if not live:
        st.info(
            "Offline demo mode is active. Relevant evidence can be retrieved "
            "and cited, but the application is not calling a live LLM."
        )

    st.divider()
    st.subheader("Add enterprise documents")

    files = st.file_uploader(
        "Upload PDF, DOCX, PPTX, TXT, MD or CSV files",
        type=[
            ext.lstrip(".")
            for ext in sorted(SUPPORTED_EXTENSIONS)
        ],
        accept_multiple_files=True,
    )

    if st.button(
        "Save documents and rebuild index",
        type="primary",
        use_container_width=True,
        disabled=not files,
    ):
        try:
            settings.data_dir.mkdir(parents=True, exist_ok=True)
            saved = []

            for uploaded in files or []:
                safe_name = Path(uploaded.name).name
                target = settings.data_dir / safe_name
                target.write_bytes(uploaded.getvalue())
                saved.append(safe_name)

            with st.spinner(
                "Extracting text, chunking and indexing documents..."
            ):
                report = ingest_documents()

            st.success(
                f"Indexed {report['chunk_count']} chunks from "
                f"{len(report['source_files'])} file(s)."
            )

            st.json(
                {
                    "uploaded": saved,
                    "vector_index": report["vector_index"],
                }
            )

        except Exception as exc:
            st.error(
                f"Document ingestion failed: {type(exc).__name__}: {exc}"
            )

    st.divider()
    st.subheader("Configuration checks")

    warnings = validate_settings()

    if warnings:
        for warning in warnings:
            st.warning(warning)
    else:
        st.success("No configuration warnings.")

    st.caption(
        "For this local demo, keep the application on localhost. "
        "Do not upload confidential customer data into an unapproved environment."
    )


# ---------------------------------------------------------
# Session state
# ---------------------------------------------------------

if "messages" not in st.session_state:
    st.session_state.messages = []

if "pending_question" not in st.session_state:
    st.session_state.pending_question = None


# ---------------------------------------------------------
# Workflow overview
# ---------------------------------------------------------

col_a, col_b, col_c = st.columns(3)

with col_a:
    st.metric("Workflow", "LangGraph")

with col_b:
    st.metric("Evidence trail", "Source IDs + files")

with col_c:
    st.metric(
        "Research retry",
        f"Up to {settings.max_research_retries}",
    )


# ---------------------------------------------------------
# Conversation history
# ---------------------------------------------------------

for index, message in enumerate(st.session_state.messages):
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

        if message["role"] == "assistant" and message.get("result"):
            result = message["result"]

            render_result_details(
                result=result,
                item_key=str(result.get("trace_id") or index),
            )


# ---------------------------------------------------------
# Ask a question
# ---------------------------------------------------------

question = st.chat_input(
    "Ask about a policy, process, responsibility, approval or procedure..."
)

if not question and st.session_state.pending_question:
    question = st.session_state.pending_question
    st.session_state.pending_question = None


if question:
    st.session_state.messages.append(
        {
            "role": "user",
            "content": question,
        }
    )

    with st.chat_message("user"):
        st.markdown(question)

    with st.chat_message("assistant"):
        with st.spinner(
            "Researching documents and checking source references..."
        ):
            try:
                result = answer_question(question)

                answer = result.get(
                    "answer",
                    "The agent did not return an answer.",
                )

                st.session_state.messages.append(
                    {
                        "role": "assistant",
                        "content": answer,
                        "result": result,
                    }
                )

                # Re-render the page to display the answer,
                # its sources, validation and reviewer controls.
                st.rerun()

            except Exception as exc:
                error_message = (
                    f"The request failed: {type(exc).__name__}: {exc}"
                )

                st.error(error_message)
                st.caption(
                    "Check the terminal logs. For live mode, confirm that "
                    "the selected NVIDIA model and endpoint are enabled."
                )

                st.session_state.messages.append(
                    {
                        "role": "assistant",
                        "content": error_message,
                    }
                )


# ---------------------------------------------------------
# Sample questions
# ---------------------------------------------------------

if (
    not st.session_state.messages
    and not st.session_state.pending_question
):
    st.markdown("### Try a sample question")

    examples = [
        "What expenses require manager approval?",
        "What are the rules for handling confidential data?",
        "How should an employee request remote work?",
        "What are the steps for an emergency production change?",
    ]

    cols = st.columns(2)

    for i, example in enumerate(examples):
        with cols[i % 2]:
            if st.button(
                example,
                use_container_width=True,
                key=f"sample_{i}",
            ):
                st.session_state.pending_question = example
                st.rerun()