"""CLI to rebuild the enterprise document index."""
from __future__ import annotations

import sys
from pathlib import Path
ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))
import json
from knowledge_agent.ingestion import ingest_documents

if __name__ == "__main__":
    print(json.dumps(ingest_documents(), indent=2, ensure_ascii=False))
