# Employee Handbook — Sample Demo Policy

## Working hours and attendance
Employees should follow the working schedule agreed with their team. Planned changes to working hours should be discussed with the line manager in advance. For an urgent absence, the employee should notify their manager as soon as reasonably possible.

## Learning and development
Employees may request role-relevant training through their manager. The request should describe the skill, business reason, expected outcome, and estimated cost. Manager approval is required before a paid course or certification is purchased.

## Remote work
Remote work depends on role requirements, team coverage, client commitments, and company policy. Employees should request a remote-work arrangement from their manager before the arrangement begins. Approval should be recorded in the team's agreed system. Sensitive company information must only be accessed using approved devices and company-approved secure connections.

## Performance and escalation
Employees should discuss blockers and changing priorities with their manager. If an issue affects a client commitment or delivery milestone, it should be escalated promptly through the project lead or established delivery process.

This is fictional sample content created solely for demonstration. It is not an official Capgemini policy or an authoritative HR document.
