"""NVIDIA embedding adapter with explicit passage/query input types."""

from __future__ import annotations

import math
from typing import Sequence

from openai import OpenAI
from langchain_core.embeddings import Embeddings


class NVIDIAEmbeddingAdapter(Embeddings):
    """Generate passage and query embeddings using NVIDIA's API."""

    def __init__(
        self,
        model: str,
        api_key: str,
        base_url: str | None = None,
        timeout: float = 45.0,
        batch_size: int = 16,
    ) -> None:
        if not api_key or not api_key.strip():
            raise ValueError("NVIDIA_API_KEY is required for embeddings.")

        if batch_size < 1:
            raise ValueError("batch_size must be at least 1.")

        self.model = model
        self.batch_size = batch_size

        self.client = OpenAI(
            api_key=api_key.strip(),
            base_url=(
                base_url or "https://integrate.api.nvidia.com/v1"
            ).strip(),
            timeout=timeout,
            max_retries=2,
        )

    def _embed(
        self,
        texts: Sequence[str],
        input_type: str,
    ) -> list[list[float]]:
        """Embed texts in bounded batches and preserve input order."""
        if input_type not in {"passage", "query"}:
            raise ValueError("input_type must be 'passage' or 'query'.")

        if not texts:
            return []

        results: list[list[float]] = []
        expected_dimensions: int | None = None

        for start in range(0, len(texts), self.batch_size):
            batch = list(texts[start : start + self.batch_size])

            if any(not text.strip() for text in batch):
                raise ValueError("Embedding input cannot contain blank text.")

            response = self.client.embeddings.create(
                model=self.model,
                input=batch,
                extra_body={"input_type": input_type},
            )

            # API responses carry an input index; preserve document order.
            ordered = sorted(response.data, key=lambda item: item.index)

            if len(ordered) != len(batch):
                raise RuntimeError(
                    "Embedding API returned an unexpected number of vectors."
                )

            for item in ordered:
                vector = [float(value) for value in item.embedding]

                if not vector or not all(math.isfinite(v) for v in vector):
                    raise RuntimeError(
                        "Embedding API returned an empty or invalid vector."
                    )

                if expected_dimensions is None:
                    expected_dimensions = len(vector)
                elif len(vector) != expected_dimensions:
                    raise RuntimeError(
                        "Embedding dimensions differ within the response."
                    )

                results.append(vector)

        return results

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        """Embed indexed document passages."""
        return self._embed(texts, input_type="passage")

    def embed_query(self, text: str) -> list[float]:
        """Embed a user's search query."""
        vectors = self._embed([text], input_type="query")
        return vectors[0]