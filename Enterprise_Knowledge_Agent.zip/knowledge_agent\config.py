"""Central application settings loaded from environment variables and .env."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parents[1]
load_dotenv(ROOT_DIR / ".env")


def _as_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


def _as_int(name: str, default: int, minimum: int = 1) -> int:
    try:
        return max(minimum, int(os.getenv(name, str(default))))
    except (TypeError, ValueError):
        return default


@dataclass(frozen=True)
class Settings:
    root_dir: Path = ROOT_DIR
    data_dir: Path = Path(os.getenv("DATA_DIR", str(ROOT_DIR / "data" / "documents")))
    storage_dir: Path = Path(os.getenv("STORAGE_DIR", str(ROOT_DIR / "storage")))
    log_dir: Path = Path(os.getenv("LOG_DIR", str(ROOT_DIR / "logs")))
    reports_dir: Path = Path(os.getenv("REPORTS_DIR", str(ROOT_DIR / "reports")))
    demo_mode: bool = _as_bool("DEMO_MODE", True)
    retrieval_mode: str = os.getenv("RETRIEVAL_MODE", "lexical").strip().lower()
    nvidia_api_key: str = os.getenv("NVIDIA_API_KEY", "").strip()
    nvidia_base_url: str = os.getenv("NVIDIA_BASE_URL", "").strip()
    nvidia_chat_model: str = os.getenv("NVIDIA_CHAT_MODEL", "meta/llama-3.3-70b-instruct").strip()
    nvidia_embedding_model: str = os.getenv("NVIDIA_EMBEDDING_MODEL", "nvidia/nv-embedqa-e5-v5").strip()
    top_k: int = _as_int("TOP_K", 5)
    chunk_size: int = _as_int("CHUNK_SIZE", 1200, minimum=300)
    chunk_overlap: int = _as_int("CHUNK_OVERLAP", 180, minimum=0)
    max_research_retries: int = _as_int("MAX_RESEARCH_RETRIES", 1, minimum=0)
    api_auth_token: str = os.getenv("API_AUTH_TOKEN", "").strip()
    admin_api_token: str = os.getenv("ADMIN_API_TOKEN", "").strip()

    @property
    def live_llm_enabled(self) -> bool:
        return not self.demo_mode and bool(self.nvidia_api_key or self.nvidia_base_url)

    @property
    def live_vector_enabled(self) -> bool:
        return self.retrieval_mode == "nvidia" and bool(self.nvidia_api_key or self.nvidia_base_url)

    @property
    def chunks_file(self) -> Path:
        return self.storage_dir / "chunks.jsonl"

    @property
    def chroma_dir(self) -> Path:
        return self.storage_dir / "chroma"


settings = Settings()


def validate_settings() -> list[str]:
    """Return actionable configuration warnings; do not leak secret values."""
    warnings: list[str] = []
    if not settings.demo_mode and not (settings.nvidia_api_key or settings.nvidia_base_url):
        warnings.append("DEMO_MODE=false but no NVIDIA_API_KEY or NVIDIA_BASE_URL is configured. The app will use the offline demo synthesizer.")
    if settings.retrieval_mode == "nvidia" and not settings.live_vector_enabled:
        warnings.append("RETRIEVAL_MODE=nvidia requires NVIDIA_API_KEY or NVIDIA_BASE_URL; lexical retrieval will be used instead.")
    if settings.chunk_overlap >= settings.chunk_size:
        warnings.append("CHUNK_OVERLAP should be smaller than CHUNK_SIZE.")
    return warnings
