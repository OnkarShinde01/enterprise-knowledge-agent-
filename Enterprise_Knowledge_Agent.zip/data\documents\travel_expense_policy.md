# Travel and Expense Policy — Sample Demo Policy

## Business travel approval
Business travel must be approved by the employee's manager before bookings are made. The request should include the business purpose, destination, dates, estimated total cost, and cost centre. International travel may require additional approval under the applicable business-unit process.

## Expense claims
Employees should submit expense claims through the approved expense system within 30 calendar days after the trip ends. Each claim must include an itemized receipt where available, the business purpose, date, currency, and cost centre. Claims should be accurate and must not include personal expenses.

## Meals and local transport
Reasonable business meal and local-transport costs may be reimbursed when they are necessary for approved business travel and supported by the required receipts. Alcohol, personal entertainment, and costs for family members are not reimbursable under this sample policy.

## Exceptions
Any exception to a stated expense limit must be approved in writing by the employee's manager before the cost is incurred, unless an emergency makes advance approval impractical. The employee should document the reason and seek approval as soon as possible afterward.

This is fictional sample content created solely for demonstration. It is not an official Capgemini finance or travel policy.
