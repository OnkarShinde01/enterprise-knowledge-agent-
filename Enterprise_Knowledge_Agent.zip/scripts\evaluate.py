"""Run a small deterministic evaluation suite and save a machine-readable report."""
from __future__ import annotations

import sys
from pathlib import Path
ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

import json
from datetime import datetime, timezone
from knowledge_agent.config import settings
from knowledge_agent.graph import answer_question

EVAL_FILE = settings.root_dir / "data" / "evaluation_questions.json"


def run_evaluation() -> dict:
    cases = json.loads(EVAL_FILE.read_text(encoding="utf-8"))
    results = []
    for case in cases:
        response = answer_question(case["question"])
        retrieved_files = {s.get("source") for s in response["sources"]}
        expected_files = set(case.get("expected_sources", []))
        cited_ids = set(response["validation"].get("valid_citations", []))
        results.append({
            "case_id": case["id"],
            "question": case["question"],
            "expected_sources": sorted(expected_files),
            "retrieved_sources": sorted(x for x in retrieved_files if x),
            "expected_source_hit": bool(expected_files & retrieved_files) if expected_files else None,
            "citation_count": len(cited_ids),
            "citation_validation_passed": response["validation"].get("passed", False),
            "citation_coverage": response["validation"].get("citation_coverage", 0),
            "latency_ms": response["latency_ms"],
            "trace_id": response["trace_id"],
        })
    scored = [r for r in results if r["expected_source_hit"] is not None]
    report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "mode": "nvidia_nim" if settings.live_llm_enabled else "offline_demo",
        "case_count": len(results),
        "expected_source_hit_rate": round(sum(r["expected_source_hit"] for r in scored) / max(1, len(scored)), 3),
        "citation_validation_pass_rate": round(sum(r["citation_validation_passed"] for r in results) / max(1, len(results)), 3),
        "mean_latency_ms": round(sum(r["latency_ms"] for r in results) / max(1, len(results))),
        "results": results,
        "limitations": "Starter evaluation is deterministic and checks source retrieval/citation format; it does not prove semantic entailment. Add domain-owner reviewed golden answers and an independent groundedness evaluator before production.",
    }
    settings.reports_dir.mkdir(parents=True, exist_ok=True)
    out = settings.reports_dir / "evaluation_latest.json"
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False))
    print(f"\nSaved: {out}")
    return report


if __name__ == "__main__":
    run_evaluation()
