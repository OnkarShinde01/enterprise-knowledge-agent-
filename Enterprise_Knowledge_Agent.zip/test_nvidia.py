import os
import sys
import time

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

api_key = os.getenv("NVIDIA_API_KEY")
if not api_key or api_key.strip() == "PASTE_YOUR_NEW_KEY_HERE":
    sys.exit("NVIDIA_API_KEY is missing from .env")

client = OpenAI(
    base_url=os.getenv("NVIDIA_BASE_URL")
    or "https://integrate.api.nvidia.com/v1",
    api_key=api_key.strip(),
    timeout=90.0,
    max_retries=0,
)

print("Testing NVIDIA chat endpoint...")
start = time.time()

try:
    stream = client.chat.completions.create(
        model=os.getenv(
            "NVIDIA_CHAT_MODEL",
            "nvidia/nemotron-3.5-lightning-30b-a3b",
        ),
        messages=[
            {
                "role": "system",
                "content": "Answer directly and concisely.",
            },
            {
                "role": "user",
                "content": "List three common data analysis skills.",
            },
        ],
        temperature=0.2,
        max_tokens=256,
        stream=True,
        extra_body={
            "chat_template_kwargs": {
                "enable_thinking": False
            }
        },
    )

    received_text = False

    for chunk in stream:
        if not chunk.choices:
            continue

        content = chunk.choices[0].delta.content
        if content:
            print(content, end="", flush=True)
            received_text = True

    print(f"\n\nElapsed: {time.time() - start:.1f} seconds")

    if not received_text:
        print("The request ended without returning answer text.")

except Exception as exc:
    # Avoid printing credentials or environment variables.
    print(f"\nNVIDIA test failed: {type(exc).__name__}: {exc}")