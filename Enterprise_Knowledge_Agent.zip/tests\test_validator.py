from knowledge_agent.graph import validator_node


def test_validator_accepts_valid_citation():
    state = {
        "answer": (
            "The document lists SQL, Python, and Power BI "
            "as technical skills [S1].\n"
            "- The document also mentions ETL and data quality "
            "checks [S1]."
        ),
        "hits": [{"source_id": "S1"}],
        "retry_count": 0,
    }

    result = validator_node(state)["validation"]

    assert result["passed"] is True
    assert result["valid_citations"] == ["S1"]
    assert result["invalid_citations"] == []
    assert result["citation_coverage"] == 1.0


def test_validator_rejects_unknown_source_id():
    state = {
        "answer": (
            "The policy requires approval before travel "
            "bookings are made [S2]."
        ),
        "hits": [{"source_id": "S1"}],
        "retry_count": 0,
    }

    result = validator_node(state)["validation"]

    assert result["passed"] is False
    assert result["invalid_citations"] == ["S2"]
    assert "invalid_source_reference" in result["flags"]


def test_validator_rejects_uncited_factual_answer():
    state = {
        "answer": (
            "The policy requires manager approval before "
            "international travel bookings can be made."
        ),
        "hits": [{"source_id": "S1"}],
        "retry_count": 0,
    }

    result = validator_node(state)["validation"]

    assert result["passed"] is False
    assert "no_valid_citations" in result["flags"]


def test_validator_accepts_citation_on_separate_line():
    state = {
        "answer": (
            "Business travel must be approved by the employee's "
            "manager before bookings are made.\n\n"
            "[S1]"
        ),
        "hits": [{"source_id": "S1"}],
        "retry_count": 0,
    }

    result = validator_node(state)["validation"]

    assert result["passed"] is True
    assert result["valid_citations"] == ["S1"]
    assert result["invalid_citations"] == []
    assert result["citation_coverage"] == 1.0
    assert result["flags"] == []