import os
import time

from dotenv import load_dotenv
from langchain_nvidia_ai_endpoints import ChatNVIDIA

load_dotenv()

client = ChatNVIDIA(
    model=os.getenv(
        "NVIDIA_CHAT_MODEL",
        "nvidia/nemotron-3.5-lightning-30b-a3b",
    ),
    nvidia_api_key=os.getenv("NVIDIA_API_KEY", "").strip(),
    base_url=os.getenv("NVIDIA_BASE_URL")
    or "https://integrate.api.nvidia.com/v1",
    temperature=0.1,
    max_tokens=64,
    timeout=180,
)

client = client.with_thinking_mode(enabled=False)

print("Testing LangChain NVIDIA streaming...")
start = time.time()

try:
    for chunk in client.stream("Reply with exactly: OK"):
        if isinstance(chunk.content, str) and chunk.content:
            print(chunk.content, end="", flush=True)

    print(f"\nElapsed: {time.time() - start:.1f} seconds")

except Exception as exc:
    print(f"\nFailed: {type(exc).__name__}: {exc}")