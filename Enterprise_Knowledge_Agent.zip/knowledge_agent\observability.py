"""Structured, privacy-conscious logging for request traces."""
from __future__ import annotations

import json
import logging
import time
from datetime import datetime, timezone
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any

from .config import settings

_CONFIGURED = False


def configure_logging() -> None:
    global _CONFIGURED
    if _CONFIGURED:
        return
    settings.log_dir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("knowledge_agent")
    logger.setLevel(logging.INFO)
    logger.propagate = False
    formatter = logging.Formatter("%(message)s")
    file_handler = RotatingFileHandler(settings.log_dir / "app.jsonl", maxBytes=2_000_000, backupCount=3, encoding="utf-8")
    file_handler.setFormatter(formatter)
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    _CONFIGURED = True


def log_event(event: str, **fields: Any) -> None:
    configure_logging()
    payload = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event": event,
        **fields,
    }
    # Never include API keys, full document content, or unredacted secrets in logs.
    logging.getLogger("knowledge_agent").info(json.dumps(payload, ensure_ascii=False, default=str))


def start_timer() -> float:
    return time.perf_counter()


def elapsed_ms(start: float) -> int:
    return round((time.perf_counter() - start) * 1000)
